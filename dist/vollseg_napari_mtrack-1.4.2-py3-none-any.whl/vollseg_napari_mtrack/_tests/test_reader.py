# tmp_path is a pytest fixture
def test_reader(tmp_path):

    pass


def test_get_reader_pass():
    pass
